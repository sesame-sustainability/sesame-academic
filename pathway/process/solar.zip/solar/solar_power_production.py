from core.pathway import ActivitySource
from core.inputs import CategoricalInput, ContinuousInput, OptionsInput
import core.conditionals as conditionals
import core.validators as validators
import pandas as pd
import os
import numpy as np

PATH = os.getcwd() + "/pathway/process/solar/"

MASTER_DF = pd.read_csv(PATH + "solar_master_sheet.csv")
EF_DF = pd.read_csv(PATH + "solar_ef.csv")
PARAM_DF = pd.read_csv(PATH + "solar_parameters.csv")
CF_DF = pd.read_csv(PATH + "solar_cf_table.csv")


class SolarPowerProduction(ActivitySource):

    @classmethod
    def user_inputs(cls):
        return [
            CategoricalInput('location', 'Location of Installation'),
            CategoricalInput('cell_type', 'Cell Type'),
            OptionsInput(
                'panel_type', 'Panel Produced in',
                options=['Europe', 'China'],
                conditionals=[conditionals.input_equal_to('cell_type', 'multi crystal Si (most common)')],
            ),
            CategoricalInput('install_type', 'Installation Type'),
            OptionsInput('shading', 'Shading Losses (in %)', options=[0, 2.5, 5, 7.5, 10]),
            ContinuousInput('lifetime', 'Lifetime (year)', validators=[validators.numeric(), validators.gte(0)]),
            ContinuousInput('efficiency', 'Efficiency, STC Rated',
                            validators=[validators.numeric(), validators.gte(0)]),
            ContinuousInput('degradation', 'Degradation Rate (per year)',
                            validators=[validators.numeric(), validators.gte(0)]),
            ContinuousInput('ilr', 'Inverse Loading Ratio', validators=[validators.numeric(), validators.gte(0)]),
            ContinuousInput('panel_ghg', 'Emissions in Panel Production (gCO₂e)',
                            validators=[validators.numeric(), validators.gte(0)]),
            ContinuousInput('bos_ghg', 'Emissions in BOS Production (gCO₂e)',
                            validators=[validators.numeric(), validators.gte(0)]),
            ContinuousInput('shipping_dist', 'Shipping Distance from Panel Production to Installation (km)',
                            validators=[validators.numeric(), validators.gte(0)])
        ]

    def get_inputs(self):
        if not hasattr(self,'results_overall'):
            _, self.results_overall = self.compute_emissions(MASTER_DF, EF_DF, PARAM_DF)
        upstream_emissions = self.get_stage_emissions('Upstream', self.results_overall)
        return {
            'primary': upstream_emissions,
            'secondary': []
        }

    def get_output(self):
        return self.output

    def get_emissions(self):
        process_emissions = self.get_stage_emissions('Process', self.results_overall)
        emission_flows = {}
        for substage in process_emissions:
            emission_flows[substage] = {
                'co2': {'name': 'co2', 'unit': 'gCO2eq/kWh', 'value': process_emissions[substage]}}

        return emission_flows

    def amount_factor(self, amounts, col_index):
        mf = 1
        l = len(amounts.columns)
        for i in range(col_index + 1, l - 5):
            ix_row = np.where(amounts.input == amounts.columns.values[i - 1])[0]
            a = amounts.iloc[ix_row, i].values
            mf = mf * a

        b = amounts.loc[amounts.input == amounts.columns.values[l - 2], amounts.columns.values[l - 1]].values
        c = amounts.loc[amounts.input == amounts.columns.values[l - 6], amounts.columns.values[l - 2]].values

        if col_index < l - 5:
            mf = mf * b * c
        elif col_index < l - 2:
            ix_row = np.where(amounts.input == amounts.columns.values[col_index])[0]
            a = amounts.iloc[ix_row, l - 2].values
            mf = mf * a * b
        elif col_index == l - 2:
            mf = mf * b

        if mf == 1:
            mf = [1]
        return mf[0]

    def panel_install(self, params):
        i = 0 if self.install_type in ['rooftop, typical tilt', 'rooftop, optimal tilt'] else 1
        a_pi = self.ilr * float(params['Value'][i]) / (float(params['Value'][2]) * self.efficiency) * (
                1 + float(params['Value'][6]) + float(0.02 * self.lifetime / 30))
        return a_pi

    def mount_install(self, a_pi, params):
        a_mi = a_pi / (1 + float(params['Value'][6]) + float(params['Value'][7]) * self.lifetime)
        return a_mi

    def powerplant_operation(self, CF, params):
        i = 0 if self.install_type in ['rooftop, typical tilt', 'rooftop, optimal tilt'] else 1
        a_ppo = 1 / (CF * float(params['Value'][i]) * self.lifetime)
        return a_ppo

    def transportation(self, a_pi, a0, areal_density):
        a_transport = a0 + a_pi * 0.001 * self.shipping_dist * areal_density
        return a_transport

    def compute_cap_fac(self, cf_table):
        assumed_loss = 0.03
        tec = 0.4223  # Typical tracker energy consumption per panel area in kWh/m²/yr

        pat = ' Si' if 'Si' in self.cell_type else ' TF'
        column_key = self.install_type + pat
        cf_row = cf_table.loc[cf_table['Location'] == self.location]

        # Calculation of required CF
        cf_loc = cf_row[column_key].values
        snow_loss = cf_row['snow loss if any (%)'].values
        CF_AC = (cf_loc * (1 - snow_loss) * (1 - self.shading/100) * (1 - self.lifetime * self.degradation / 200) / (
                1 - assumed_loss) - 100 * tec / self.efficiency / 8760) * self.ilr
        CF_DC = CF_AC / self.ilr
        CF_AC_per_cap = CF_AC * 87.6

        cap_fac = np.concatenate((CF_AC, CF_DC, CF_AC_per_cap), axis=None)
        return cap_fac

    def compute_emissions(self, master, ef, params):

        ef.iloc[0, -1] = self.panel_ghg / 1000
        if self.cell_type == "multi crystal Si (most common)":
            self.cell_type = "multi crystal Si"
        pat1 = "rooftop" if "rooftop" in self.install_type else self.install_type
        pat2 = self.cell_type + ' '
        if self.cell_type == "multi crystal Si":
            pat2 += str(self.panel_type)
        self.efficiency = self.efficiency/100
        columns = master.columns.values
        relevant_install_columns = columns[[i for i, item in enumerate(columns) if pat1 in item]]
        relevant_cell_columns = columns[[i for i, item in enumerate(columns) if pat2 in item]]
        relevant_columns = np.concatenate(('input', relevant_cell_columns, relevant_install_columns), axis=None)
        amounts = master.filter(relevant_columns, axis=1)

        # Calculation of User Input dependent variables in Amounts
        CF = self.compute_cap_fac(CF_DF)

        a_pi = self.panel_install(params)
        a_mi = self.mount_install(a_pi, params)
        a_ppo = self.powerplant_operation(CF[2], params)
        a0_transport = amounts.loc[amounts.input == 'transoceanic freight ship', relevant_install_columns[-2]].values
        a_transport = self.transportation(a_pi, a0_transport,
                                          float(params.loc[params['Parameter Abbreviation'] == 'ad', 'Value'].values))

        amounts.loc[amounts.input == relevant_cell_columns[-1], relevant_install_columns[-2]] = a_pi
        amounts.loc[amounts.input == relevant_install_columns[2], relevant_install_columns[-2]] = a_mi
        amounts.loc[amounts.input == relevant_install_columns[-2], relevant_install_columns[-1]] = a_ppo
        amounts.loc[amounts.input == 'transoceanic freight ship', relevant_install_columns[-2]] = a_transport

        # Calculation of emissions
        ghg = amounts.copy()
        results_index = ['GHG Emissions by stage product (including previous stages)',
                         'GHG Emissions by stage product (excluding previous stages)',
                         'GHG Emissions (including previous stages)', 'GHG Emissions (excluding previous stages)',
                         'Stage']
        results = pd.DataFrame(index=results_index, columns=relevant_columns)

        l = len(amounts.columns)
        results.iloc[4, 1:l - 2] = ['Upstream'] * (l - 3)
        results.iloc[4, l - 2:l] = ['Process'] * (2)

        for (columnName, columnData) in amounts.iteritems():
            if columnName == 'input':
                continue
            col_index = amounts.columns.get_loc(columnName)

            if col_index < l - 5:
                ef.iloc[0, -2] = self.panel_ghg / 1000

            else:
                ef.iloc[0, -2] = self.bos_ghg / 1000

            val = amounts[columnName].mul(ef['values'], 1)
            ghg.loc[:, columnName] = list(val)
            calc_sum = ghg[columnName].sum()

            results.loc['GHG Emissions by stage product (including previous stages)', columnName] = calc_sum
            results.loc['GHG Emissions by stage product (excluding previous stages)', columnName] = calc_sum - ghg.loc[
                                                                                                               39:60,
                                                                                                               columnName].sum()
            mf = self.amount_factor(amounts, col_index)

            results.loc['GHG Emissions (including previous stages)', columnName] = calc_sum * mf
            if col_index == 1 or col_index == l - 3 or col_index == l - 4 or col_index == l - 5:
                results.loc['GHG Emissions (excluding previous stages)', columnName] = calc_sum * mf
            elif col_index == l - 1 or col_index == l - 2:
                results.loc['GHG Emissions (excluding previous stages)', columnName] = calc_sum * mf - results.loc[
                    'GHG Emissions (excluding previous stages)', amounts.columns.values[1: col_index]].sum()
            else:
                results.loc['GHG Emissions (excluding previous stages)', columnName] = calc_sum * mf - results.loc[
                    'GHG Emissions (including previous stages)', amounts.columns.values[col_index - 1]]

            if 'operation' in columnName:
                continue
            else:
                ef.loc[ef.input == columnName, 'values'] = calc_sum
        # print(results.iloc[3,:])
        return ghg, results

    def get_stage_emissions(self, stage, results):
        stage_emissions = {}
        last_two = results.loc[['GHG Emissions (excluding previous stages)', 'Stage']].to_dict()
        for sub_stage, value_dict in last_two.items():
            if sub_stage != 'input':
                if value_dict['Stage'] == stage:
                    stage_emissions[sub_stage] = value_dict['GHG Emissions (excluding previous stages)']
        return stage_emissions
